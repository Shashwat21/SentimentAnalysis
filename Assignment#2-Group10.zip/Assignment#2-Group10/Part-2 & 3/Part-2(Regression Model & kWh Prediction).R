library(MASS)
library(ISLR)
library(leaps)
library(dplyr)
library(DAAG)


input<- read.csv("C:/Users/goyal/Desktop/ADS/Assignment 2/Assignment/sampleformat.csv",header = T)

#df_input = df_input %>% mutate(Conditions = ifelse(Conditions == 'Light Snow'| Conditions=='Partly Cloudy'|Conditions=='Scattered Clouds',0,1))

#70% of sample size
smp_size <- floor(0.70 * nrow(df_input))

#Set the seed to make your partition reproductible
set.seed(123)
train_ind <- sample(seq_len(nrow(df_input)), size = smp_size)

#Split the data into training and testing
train_data <- df_input[train_ind, ]
test_data <- df_input[-train_ind, ]


#Forward Selection
regfit.fwd=regsubsets(kWh~.-Date -Account -Year -Wind_Direction -Conditions, data=train, nvmax=13, method="forward")
F=summary(regfit.fwd)
names(F)
F
plot(regfit.fwd,scale = "adjr2")
plot(F$rss)
F$rss
plot(F$adjr2)
F$adjr2
coef(regfit.fwd,11)



#Backward Selection
regfit.bwd=regsubsets(kWh~.-Date -Account -Year -Wind_Direction -Conditions, data=train, nvmax=13, method="backward")
F=summary(regfit.bwd)
names(F)
F
plot(F$rss)
plot(F$adjr2)
F$adjr2
coef(regfit.bwd,11)


#fitting regression model 
lm.fit = lm(kWh ~ Hours+TemperatureF+Month+Day+PeakHours+DayOfWeek+
              WeekDay+Dew_PointF+Humidity+Sea_Level_PressureIn+VisibilityMPH, data = train_data)
summary(lm.fit)


#using step AIC 
step <- stepAIC(lm.fit, direction="both")
step$anova
# less AIC is better

#cross validate 3 fold (lesser the mean value better the model)
CVlm(df_input, lm.fit, m=3)

#Summary of the fit
reg_summary<-summary(lm.fit)
reg_input<-reg_summary$coefficients[,1]
reg_coefficient<-coefficients(reg_summary)
View(reg_coefficient)
write.csv(reg_input, file="C:/Users/goyal/Desktop/ADS/Assignment 2/Assignment/regression_output.csv")


#prediction
reg_pred = predict(lm.fit, test_data)
reg_acc<-accuracy(reg_pred, test_data$kWh)
rmse = sqrt(mean(mean(test_data$kWh)-reg_acc)^2)
View(reg_acc)
write.csv(reg_acc, file="C:/Users/goyal/Desktop/ADS/Assignment 2/Assignment/regressionperformance_matrix.csv")



#forecasting kwh
forecast_File = read.csv(file = "C:/Users/goyal/Desktop/ADS/Assignment 2/final-parseddata-input.csv", header = TRUE,sep = ',')

forecast_File1 = forecast_File %>% dplyr::select(-c(Year,Date,Wind_Direction,Conditions,WindDirDegrees,Wind_SpeedMPH))

forecast_File$kWh = predict(lm.fit,newdata = forecast_File1)
forecast_File = tbl_df(forecast_File)

df1=cbind(forecast_File[1], Hour=forecast_File$Hours, Temperature=forecast_File$TemperatureF,kWh=forecast_File$kWh)
View(df1)

write.csv(df1, file="C:/Users/goyal/Desktop/ADS/Assignment 2/Assignment/forecast-output.csv")
