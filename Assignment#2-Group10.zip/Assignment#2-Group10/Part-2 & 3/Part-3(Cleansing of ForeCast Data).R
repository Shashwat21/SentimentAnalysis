library(sqldf)
library(dplyr)
library(tidyr)

raw_input1 <- read.csv("C:/Users/goyal/Desktop/ADS/Assignment 2/forecastData.csv", header=T)
raw_df <- data.frame(raw_input1) 
View(raw_df)

#fetching relevant columns
new_df11<-cbind(raw_df[1:10], Conditions=raw_df$Conditions, WindDirDegrees=raw_df$WindDirDegrees)
View(new_df11)

#parsing date to get year, month, day, hour

new_df11$Time = as.POSIXct(new_df11$Time)
Year=as.numeric(strftime(new_df11$Time,"%Y"))
Month=as.numeric(strftime(new_df11$Time,"%m"))
Day=as.numeric(strftime(new_df11$Time,"%d"))
Hour=as.numeric(strftime(new_df11$Time,"%H"))
Date= as.Date(strftime(new_df11$Time,"%Y-%m-%d"))
Date = as.Date(Date)
View(new_df11)
new_df1=cbind(Date,Year,Month,Day,Hour,new_df11)
View(new_df1)

#refining data types
new_df1$Humidity=as.numeric(new_df1$Humidity)
new_df1$Wind_SpeedMPH=as.numeric(new_df1$Wind_SpeedMPH)
new_df1$TemperatureF=as.numeric(new_df1$TemperatureF)
new_df1$Dew_PointF=as.numeric(new_df1$Dew_PointF)
new_df1$Sea_Level_PressureIn=as.numeric(new_df1$Sea_Level_PressureIn)
new_df1$VisibilityMPH=as.numeric(new_df1$VisibilityMPH)
new_df1$WindDirDegrees = as.numeric(new_df1$WindDirDegrees)
new_df1$Conditions=as.character(new_df1$Conditions)
new_df1$Wind_Direction=as.character(new_df1$Wind_Direction)
class(new_df1$Wind_Direction)

#aggregating row values by date, hour

new_df2 = summarise(group_by(new_df1,Date,Year, Month,Day, Hour),TemperatureF=mean(TemperatureF),
                    Dew_PointF=mean(Dew_PointF),Humidity=mean(Humidity),Sea_Level_PressureIn=mean(Sea_Level_PressureIn),
                    VisibilityMPH=mean(VisibilityMPH),Wind_SpeedMPH=mean(Wind_SpeedMPH),
                    Conditions=max(Conditions),Wind_Direction=max(Wind_Direction),WindDirDegrees=mean(raw_df$WindDirDegrees))
View(new_df2)

# peakhours,weekday, dayofWeek
library(lubridate)

new_df2$DayOfWeek <-(wday(new_df2$Date))-1
new_df2$WeekDay = ifelse(new_df2$DayOfWeek == 0 | new_df2$DayOfWeek == 6 , 0 , 1)
new_df2$PeakHours = ifelse(new_df2$Hour >= 19 | new_df2$Hour <= 6, 0 , 1)
View(new_df2)

#reordering columns

new_df2=new_df2[c("Date", "Month", "Day","Year","Hour","DayOfWeek","WeekDay","PeakHours",
                  "TemperatureF","Dew_PointF","Humidity","Sea_Level_PressureIn","VisibilityMPH",
                  "Wind_Direction","Wind_SpeedMPH","Conditions","WindDirDegrees")]
View(new_df2)
#writing in csv

write.csv(new_df2[,(1:17)],"C:/Users/goyal/Desktop/ADS/Assignment 2/final-parseddata-input.csv",row.names = FALSE)



