setwd("C:/Users/Shashwat/Desktop/NEU/Semester 3/Advances in Data Science/Assignments/Assignment#2/Assignment 2/Assignment 2(1)")
library(dplyr)
library(tidyr)
#---------------Reading the Data   ---------------
rawFinal = read.csv("Raw_Final.csv")
weatherFinal = read.csv("Weather_Final.csv")

#---------------Inner Join Data   ---------------
#finalData = merge(x = rawFinal,weatherFinal,by=c("Date","Hours"),all.x=TRUE) 
finalData = inner_join(rawFinal,weatherFinal, by = c("Date","Hours"))

#---------------Dropping Columns which are not required   ---------------
drops = c("Channel")
finalData = finalData[,!(names(finalData) %in% drops)]
Date = finalData$Date
#View(finalData)

#---------------Separating Date into Year Month Day   ---------------
finalData = finalData %>% separate(Date,c("Year","Month","Day"),sep="-")
finalData = cbind(finalData,Date)
finalData = tbl_df(finalData)
View(finalData)
#---------------Rearranging Columns   ---------------
rearrangedData = finalData[,c(1,19,9,3,4,2,5,6:8,10:18)]
View(rearrangedData)
#---------------Storing it into .csv   ---------------
write.csv(rearrangedData,"FinalData.csv",row.names = FALSE)