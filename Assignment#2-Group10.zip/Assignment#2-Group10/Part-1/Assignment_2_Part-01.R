library(sqldf)
library(dplyr)
library(tidyr)
library(lubridate)
setwd("C:/Users/Shashwat/Desktop/NEU/Semester 3/Advances in Data Science/Assignments/Assignment#2/Assignment 2/Assignment 2(1)")
#-------------- Reading the Data:-------------- 
rawData1 = read.csv("rawData1.csv",na.strings=c(""," ",0))
rawData1[is.na(rawData1)] <- 0
rawData2 = read.csv("rawData2.csv",na.strings=c(""," ",0))
rawData1[is.na(rawData1)] <- 0

#-------------- Converting into table:-------------- 
rawData = tbl_df(rawData1)
rawData = tbl_df(rawData2)

#-------------- Binding two files: -------------- 
mergedData = rbind(rawData1,rawData2)
write.csv(mergedData,"MergedData.csv",quote= FALSE,row.names = FALSE)
View(mergedData)
#-------------- Filtering out PowerFactor and KVarh -----------------
#cleanData = mergedData[mergedData$Units!= 'Power Factor' & mergedData$Units!= 'kVARh', ]
#attach(cleanData)
cleanData = read.csv.sql("MergedData.csv",sql = "select * from file where Units = 'kWh' AND 
                         (Channel = 'MILDRED SCHOOL 1' OR Channel = 'MILDRED SCHOOL 2') ")
#write.csv(cleanData,"step1Data.csv",quote= FALSE,row.names = FALSE)
View(cleanData)
#-------------- Gathering & Separating Data: -----------------
cleanData$Date<-as.Date(as.character(cleanData$Date),format = "%m/%d/%Y")
rawCheck = cleanData %>% gather(Time, Rating, X0.05:X24.00)
rawCheck = rawCheck %>% mutate(Rating=ifelse(Rating=="",0,Rating))
rawCheck = rawCheck %>% separate(Time,c("ExtraVar","ActualTime"),1)
rawCheck = rawCheck %>% separate(ActualTime,c("Hours","Minutes"))
rawCheck = rawCheck %>% arrange(Date,Channel,Hours,Minutes)
View(rawCheck)
#-------------- Calculating Differnt Fields: -----------------
rawCheck = rawCheck %>% mutate(Hours = ifelse(Minutes == '00',as.numeric(Hours)-1,Hours),
                                 Minutes = ifelse(Minutes == '00','59',Minutes))
rawCheck$Hours = as.numeric(rawCheck$Hours)
#1. Day of Week
DayOfWeek = (wday(rawCheck$Date))-1
rawCheck = cbind(rawCheck,DayOfWeek)
#2. WeekDay
WeekDay = ifelse(rawCheck$DayOfWeek == 0 | rawCheck$DayOfWeek == 6 , 0 , 1)
rawCheck = cbind(rawCheck,WeekDay)
#3. PeakHours
PeakHours = ifelse(rawCheck$Hours >= 19 | rawCheck$Hours <= 6, 0 , 1)
rawCheck = cbind(rawCheck,PeakHours)
#4. Summarising and Group By for SumRating
rawCheck = summarise(group_by(rawCheck,Account,Date,Channel,Hours,DayOfWeek,WeekDay,PeakHours),kWh=sum(Rating))
write.csv(rawCheck,"Raw_Final.csv",row.names = FALSE)
class(rawCheck$Date)
#5. Sorting
#rawCheck = rawCheck[order(rawCheck$Account,rawCheck$Date,rawCheck$Channel,rawCheck$Hours),]
#6. Seperating Date Field
#rawCheck = rawCheck %>% separate(Date,c("Year","Month","Day"),sep="-")
#View(rawCheck)
#class(rawCheck$Date)