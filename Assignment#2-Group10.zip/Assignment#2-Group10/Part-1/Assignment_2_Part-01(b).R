setwd("C:/Users/Shashwat/Desktop/NEU/Semester 3/Advances in Data Science/Assignments/Assignment#2/Assignment 2/Assignment 2(1)")
library(sqldf)
library(dplyr)
library(tidyr)
library(zoo)
library(weatherData)
#---------------Getting the Data for 1 Year for location "KBOS" ---------------
#dfw_wx<-getWeatherForDate("KBOS", start_date="2014/01/01", end_date="2014/12/31",opt_detailed=TRUE,opt_custom_columns=TRUE, custom_columns=c(2,3,4,5,6,7,8,12,13)) 
dfw_wx = read.csv("Weather_actual.csv")
View(dfw_wx1)
#---------------Setting the Wind_Speed = 0 for "Calm"           ---------------
dfw_wx$Wind_SpeedMPH=ifelse(dfw_wx$Wind_SpeedMPH=='Calm',0,dfw_wx$Wind_SpeedMPH)

#---------------Converting Wind_Speed and Humidity to numeric   ---------------
dfw_wx$Wind_SpeedMPH=as.numeric(dfw_wx$Wind_SpeedMPH)
dfw_wx$Humidity=as.numeric(dfw_wx$Humidity)

#---------------Handling Outliers Values                        ---------------
dfw_wx = dfw_wx %>% mutate(TemperatureF = ifelse(TemperatureF < -126 | TemperatureF > 136,NA,TemperatureF),
                           Dew_PointF = ifelse(Dew_PointF < -60 | Dew_PointF > 95,NA,Dew_PointF),
                           Humidity = ifelse(Humidity<0,NA,Humidity),
                           Sea_Level_PressureIn = ifelse(Sea_Level_PressureIn > 35 | Sea_Level_PressureIn <10,NA,Sea_Level_PressureIn),
                           VisibilityMPH = ifelse(VisibilityMPH > 10 | VisibilityMPH < -10,NA,VisibilityMPH),
                           Wind_SpeedMPH = ifelse(Wind_SpeedMPH > 1000 | Wind_SpeedMPH < 0,NA,Wind_SpeedMPH))
#for (i in 1:10) dfw_wx[,i]<-na.locf(dfw_wx[,i])
dfw_wx = dfw_wx %>% do(na.locf(.))
dfw_wx = dfw_wx %>% separate(Time,c("Date","Time_Stamp"),sep=" ")
dfw_wx= dfw_wx %>% separate(Time_Stamp,c("Hours"),sep=":")

#---------------Converting chr to numeric   ---------------
dfw_wx$Wind_SpeedMPH=as.numeric(dfw_wx$Wind_SpeedMPH)
dfw_wx$Humidity=as.numeric(dfw_wx$Humidity)
dfw_wx$TemperatureF=as.numeric(dfw_wx$TemperatureF)
dfw_wx$Dew_PointF=as.numeric(dfw_wx$Dew_PointF)
dfw_wx$Sea_Level_PressureIn=as.numeric(dfw_wx$Sea_Level_PressureIn)
dfw_wx$VisibilityMPH=as.numeric(dfw_wx$VisibilityMPH)
dfw_wx$Hours=as.numeric(dfw_wx$Hours)
dfw_wx$WindDirDegrees = as.numeric(dfw_wx$WindDirDegrees)
dfw_wx = tbl_df(dfw_wx)
dfw_wx1 = summarise(group_by(dfw_wx,Date,Hours),TemperatureF=mean(TemperatureF),Dew_PointF=mean(Dew_PointF),Humidity=mean(Humidity),Sea_Level_PressureIn=mean(Sea_Level_PressureIn),VisibilityMPH=mean(VisibilityMPH),Wind_Direction=max(Wind_Direction),
                    Wind_SpeedMPH=mean(Wind_SpeedMPH),Conditions=max(Conditions),WindDirDegrees=mean(WindDirDegrees))
#dfw_wx = tbl_df(dfw_wx)
dfw_wx1$Date = as.Date(dfw_wx1$Date)
write.csv(dfw_wx1[,(1:11)],"Weather_Final.csv",row.names = FALSE)
class(dfw_wx1$Date)