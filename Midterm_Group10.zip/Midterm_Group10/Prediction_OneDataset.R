#Load Libraries
#Libraries used
library(dplyr)
library(forecast)
library(leaps)
library(caret)
library(glmnet)
library(DAAG)
library(sqldf)
library(grid)
library(neuralnet)
library(dplyr)
library(FNN)
library(randomForest)
createKNNOne = function(KnnModellingData){
  #Knn
  
  #Get path
  getwd()
  
  #read file
  KnnModellingData <- read.csv(file="Final_Finland_Data.csv",header=TRUE,sep=",")
  KnnModellingData <- KnnModellingData %>% select(-c(BuildingID,BuildingName,MeterID,
                                                     type,Date,nearestAirport,Wind_Direction,
                                                     Conditions,Gust_SpeedMPH,PrecipitationIn,
                                                     Events,VisibilityMPH,address,day,month,
                                                     Base_Hour_Class))
  
  #scaling
  KnnModellingData$TemperatureF = scale(as.numeric(KnnModellingData$TemperatureF),
                                        center = TRUE,scale = TRUE)
  KnnModellingData$Dew_PointF = scale(as.numeric(KnnModellingData$Dew_PointF),
                                      center = TRUE,scale = TRUE)
  KnnModellingData$Humidity = scale(as.numeric(KnnModellingData$Humidity),
                                    center = TRUE,scale = TRUE)
  KnnModellingData$Sea_Level_PressureIn = scale(as.numeric(KnnModellingData$Sea_Level_PressureIn),
                                                center = TRUE,scale = TRUE)
  KnnModellingData$Wind_SpeedMPH = scale(as.numeric(KnnModellingData$Wind_SpeedMPH),
                                         center = TRUE,scale = TRUE)
  KnnModellingData$WindDirDegrees = scale(as.numeric(KnnModellingData$WindDirDegrees),
                                          center = TRUE,scale = TRUE)
  KnnModellingData$DayNumber = scale(as.numeric(KnnModellingData$DayNumber),
                                     center = TRUE,scale = TRUE)
  KnnModellingData$MonthNumber = scale(as.numeric(KnnModellingData$MonthNumber),
                                       center = TRUE,scale = TRUE)
  KnnModellingData$base_hr_usage = scale(as.numeric(KnnModellingData$base_hr_usage),
                                         center = TRUE,scale = TRUE)
  KnnModellingData$WeekDay = scale(as.numeric(KnnModellingData$Weekday),
                                   center = TRUE,scale = TRUE)
  KnnModellingData$Base_Hour_Flag = scale(as.numeric(KnnModellingData$Base_Hour_Flag),
                                          center = TRUE,scale = TRUE)
  
  #70% of the sample size
  smp_size <- floor(0.70 * nrow(KnnModellingData))
  
  #Set the seed to make your partition reproducible.
  set.seed(123)
  train_ind <- sample(seq_len(nrow(KnnModellingData)), size = smp_size)
  
  #Splitting the data into training and testing
  train_data <- KnnModellingData[train_ind, ]
  test_data <- KnnModellingData[-train_ind, ]
  
  #Build the model
  knn.model <- knn.reg(train_data[,-2], test_data[,-2], y = train_data$Consumption, 
                       k = 5, algorithm= "kd_tree")
  
  
  #Predict Accuracy
  knnDataFrame = data.frame(actual= test_data$Consumption, predicted = knn.model$pred)
  reg_acc<-accuracy(knnDataFrame$predicted, knnDataFrame$actual)
  rmse = sqrt(mean(mean(test_data$Consumption)-reg_acc)^2)
  View(reg_acc)
  
  write.csv(reg_acc, "Knn_FullData.csv", row.names = FALSE)
}

createNeuralNetworkOne = function(NNModellingData){
  #Neural Network Modelling

  NNModellingData<- NNModellingData %>% select(-c(BuildingID,BuildingName,MeterID,
                                                  type,Date,nearestAirport,Wind_Direction,
                                                  Conditions,Gust_SpeedMPH,PrecipitationIn,Events,
                                                  VisibilityMPH,address,Base_Hour_Class,day,month))
  
  #View(ModellingData)
  NNModellingData$TemperatureF = scale(as.numeric(NNModellingData$TemperatureF),
                                       center = TRUE,scale = TRUE)
  NNModellingData$Dew_PointF = scale(as.numeric(NNModellingData$Dew_PointF),
                                     center = TRUE,scale = TRUE)
  NNModellingData$Humidity = scale(as.numeric(NNModellingData$Humidity),
                                   center = TRUE,scale = TRUE)
  NNModellingData$Sea_Level_PressureIn = scale(as.numeric(NNModellingData$Sea_Level_PressureIn),
                                               center = TRUE,scale = TRUE)
  NNModellingData$Wind_SpeedMPH = scale(as.numeric(NNModellingData$Wind_SpeedMPH),
                                        center = TRUE,scale = TRUE)
  NNModellingData$WindDirDegrees = scale(as.numeric(NNModellingData$WindDirDegrees),
                                         center = TRUE,scale = TRUE)
  NNModellingData$DayNumber = scale(as.numeric(NNModellingData$DayNumber),
                                    center = TRUE,scale = TRUE)
  NNModellingData$MonthNumber = scale(as.numeric(NNModellingData$MonthNumber),
                                      center = TRUE,scale = TRUE)
  NNModellingData$base_hr_usage = scale(as.numeric(NNModellingData$base_hr_usage),
                                        center = TRUE,scale = TRUE)
  NNModellingData$WeekDay = scale(as.numeric(NNModellingData$Weekday),
                                  center = TRUE,scale = TRUE)
  NNModellingData$Base_Hour_Flag = scale(as.numeric(NNModellingData$Base_Hour_Flag),
                                         center = TRUE,scale = TRUE)
  
  #Split the data into training and testing
  
  #70% of the sample size
  smp_size <- floor(0.70 * nrow(NNModellingData))
  
  #Set the seed to make your partition reproducible.
  set.seed(123)
  train_ind <- sample(seq_len(nrow(NNModellingData)), size = smp_size)
  
  #Splitting the data into training and testing
  train_data <- NNModellingData[train_ind, ]
  test_data <- NNModellingData[-train_ind, ]
  
  
  
  #Build the neural network (NN)
  creditnet <- neuralnet(Consumption ~ Weekday+Base_Hour_Flag+Holiday+TemperatureF+	
                           Humidity+Sea_Level_PressureIn+Wind_SpeedMPH+
                           WindDirDegrees+base_hr_usage, train_data, hidden =1, lifesign = "minimal", 
                         linear.output = TRUE, threshold = 0.1)
  
  # plot the NN
  plot(creditnet, rep = "best")
  
  ## test the resulting output
  temp_test <- subset(test_data, select = c("Weekday","Base_Hour_Flag","Holiday","TemperatureF",	
                                            "Humidity","Sea_Level_PressureIn",
                                            "Wind_SpeedMPH","WindDirDegrees","base_hr_usage"))
  
  creditnet.results <- compute(creditnet, temp_test)
  
  results <- data.frame(actual = test_data$Consumption, prediction = creditnet.results$net.result)
  
  summary(results)
  
  #Accuracy
  reg_acc <- accuracy(results[,1],results[,2])
  rmse = sqrt(mean(mean(test_data$Consumption)-reg_acc)^2)
  View(rmse)
}

createRandomForestOne = function(RFModellingData){
  #Random Forest

  RFModellingData<- RFModellingData %>% select(-c(BuildingID,BuildingName,MeterID,type,Date,
                                                  nearestAirport,Wind_Direction,Conditions,
                                                  Gust_SpeedMPH,PrecipitationIn,Events,VisibilityMPH,
                                                  address,Base_Hour_Class,day,month))
  
  
  #Scaling
  RFModellingData$TemperatureF = scale(as.numeric(RFModellingData$TemperatureF),
                                       center = TRUE,scale = TRUE)
  RFModellingData$Dew_PointF = scale(as.numeric(RFModellingData$Dew_PointF),
                                     center = TRUE,scale = TRUE)
  RFModellingData$Humidity = scale(as.numeric(RFModellingData$Humidity),
                                   center = TRUE,scale = TRUE)
  RFModellingData$Sea_Level_PressureIn = scale(as.numeric(RFModellingData$Sea_Level_PressureIn),
                                               center = TRUE,scale = TRUE)
  RFModellingData$Wind_SpeedMPH = scale(as.numeric(RFModellingData$Wind_SpeedMPH),
                                        center = TRUE,scale = TRUE)
  RFModellingData$WindDirDegrees = scale(as.numeric(RFModellingData$WindDirDegrees),
                                         center = TRUE,scale = TRUE)
  RFModellingData$DayNumber = scale(as.numeric(RFModellingData$DayNumber),
                                    center = TRUE,scale = TRUE)
  RFModellingData$base_hr_usage = scale(as.numeric(RFModellingData$base_hr_usage),
                                        center = TRUE,scale = TRUE)
  RFModellingData$WeekDay = scale(as.numeric(RFModellingData$Weekday),
                                  center = TRUE,scale = TRUE)
  RFModellingData$Base_Hour_Flag = scale(as.numeric(RFModellingData$Base_Hour_Flag),
                                         center = TRUE,scale = TRUE)
  RFModellingData$MonthNumber = scale(as.numeric(RFModellingData$MonthNumber),
                                      center = TRUE,scale = TRUE)
  
  #Split the data into training and testing
  
  #70% of the sample size
  smp_size <- floor(0.70 * nrow(RFModellingData))
  
  #Set the seed to make your partition reproducible.
  set.seed(123)
  train_ind <- sample(seq_len(nrow(RFModellingData)), size = smp_size)
  
  #Splitting the data into training and testing
  train_data <- RFModellingData[train_ind, ]
  test_data <- RFModellingData[-train_ind, ]
  
  
  
  #building Randomforest
  rf.form<-Consumption ~ Weekday+Base_Hour_Flag+Holiday+TemperatureF+	
    Humidity+Sea_Level_PressureIn+Wind_SpeedMPH+
    WindDirDegrees+base_hr_usage
  
  cross.sell.rf <- randomForest(rf.form,
                                train_data,
                                ntree=200,
                                importance=T)
  #plot the graph
  plot(cross.sell.rf)
  
  varImpPlot(cross.sell.rf,
             sort = T,
             main="Variable Importance",
             n.var=10)
  
  # Variable Importance Table
  var.imp <- data.frame(importance(cross.sell.rf,
                                   type=2))
  # make row names as columns
  #var.imp$Variables <- row.names(var.imp)
  #var.imp[order(var.imp$MeanDecreaseGini,decreasing = T),]
  
  # Predicting response variable
  test_data$predicted.response <- predict(cross.sell.rf ,test_data)
  reg_acc<-accuracy(test_data$predicted.response, test_data$Consumption)
  rmse = sqrt(mean(mean(test_data$Consumption)-reg_acc)^2)
  View(reg_acc)
  
  #Write to csv
  write.csv(reg_acc, "RandomForest_FullData.csv", row.names = FALSE)
}

createRegressionOne = function(RegModellingData){
  
  #Regression
  
  
  RegModellingData<- RegModellingData %>% select(-c(BuildingID,BuildingName,MeterID,
                                                    type,Date,nearestAirport,Wind_Direction,
                                                    Conditions,Gust_SpeedMPH,PrecipitationIn,
                                                    Events,VisibilityMPH,address,Base_Hour_Class,
                                                    day,month))
  
  
  #Scaling
  RegModellingData$TemperatureF = scale(as.numeric(RegModellingData$TemperatureF),
                                        center = TRUE,scale = TRUE)
  RegModellingData$Dew_PointF = scale(as.numeric(RegModellingData$Dew_PointF),
                                      center = TRUE,scale = TRUE)
  RegModellingData$Humidity = scale(as.numeric(RegModellingData$Humidity),
                                    center = TRUE,scale = TRUE)
  RegModellingData$Sea_Level_PressureIn = scale(as.numeric(RegModellingData$Sea_Level_PressureIn),
                                                center = TRUE,scale = TRUE)
  RegModellingData$Wind_SpeedMPH = scale(as.numeric(RegModellingData$Wind_SpeedMPH),
                                         center = TRUE,scale = TRUE)
  RegModellingData$WindDirDegrees = scale(as.numeric(RegModellingData$WindDirDegrees),
                                          center = TRUE,scale = TRUE)
  RegModellingData$DayNumber = scale(as.numeric(RegModellingData$DayNumber),
                                     center = TRUE,scale = TRUE)
  RegModellingData$MonthNumber = scale(as.numeric(RegModellingData$MonthNumber),
                                       center = TRUE,scale = TRUE)
  RegModellingData$base_hr_usage = scale(as.numeric(RegModellingData$base_hr_usage),
                                         center = TRUE,scale = TRUE)
  RegModellingData$WeekDay = scale(as.numeric(RegModellingData$Weekday),
                                   center = TRUE,scale = TRUE)
  RegModellingData$Base_Hour_Flag = scale(as.numeric(RegModellingData$Base_Hour_Flag),
                                          center = TRUE,scale = TRUE)
  
  
  #70% of the sample size
  smp_size <- floor(0.70 * nrow(RegModellingData))
  
  #Set the seed to make your partition reproducible.
  set.seed(123)
  train_ind <- sample(seq_len(nrow(RegModellingData)), size = smp_size)
  
  #Splitting the data into training and testing
  train_data <- RegModellingData[train_ind, ]
  names(train_data)
  test_data <- RegModellingData[-train_ind, ]
  
  #Forward Selection
  regfit.fwd=regsubsets(Consumption ~ Weekday+Base_Hour_Flag+Holiday+TemperatureF+	
                          Humidity+Sea_Level_PressureIn+Wind_SpeedMPH+
                          WindDirDegrees+base_hr_usage, data=train_data, nvmax=11, method="forward")
  F=summary(regfit.fwd)
  names(F)
  F
  plot(regfit.fwd,scale = "adjr2")
  plot(F$rss)
  F$rss
  F$adjr2
  plot(F$adjr2)
  coef(regfit.fwd,9)
  
  
  #Backward Selection
  regfit.bwd=regsubsets(Consumption ~ Weekday+Base_Hour_Flag+Holiday+TemperatureF+	
                          Humidity+Sea_Level_PressureIn+
                          Wind_SpeedMPH+WindDirDegrees+base_hr_usage, 
                        data=train_data, nvmax=11, method="backward")
  F=summary(regfit.bwd)
  names(F)
  F
  plot(F$rss)
  plot(F$adjr2)
  F$adjr2
  coef(regfit.bwd,9)
  
  #Fit a linear regression model
  lm.fit=lm(Consumption ~ Weekday+Base_Hour_Flag+Holiday+TemperatureF+	
              Humidity+Sea_Level_PressureIn+Wind_SpeedMPH+
              WindDirDegrees+base_hr_usage,data=train_data)
  #AIC
  step <- stepAIC(lm.fit, direction="both")
  step$anova
  
  
  #Cross validate 3 fold 
  CVlm(RegModellingData, lm.fit, m=3)
  
  
  #Prediction and check accuracy
  reg_pred = predict(lm.fit, test_data)
  reg_acc<-accuracy(reg_pred, test_data$Consumption)
  rmse = sqrt(mean(mean(test_data$Consumption)-reg_acc)^2)
  View(reg_acc)
  summary(lm.fit)
  
  #Write to csv
  write.csv(reg_acc, "Regression_FullData.csv", row.names = FALSE)
}