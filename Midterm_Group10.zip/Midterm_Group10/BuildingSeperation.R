library(sqldf)
library(dplyr)
library(tidyr)
library(RCurl)
library(XML)
library(rvest)
library(data.table)
#Function which sends the filtered raw data
getFilteredRaw = function(rawData1){
  #rawData1 = read.csv(file="Finland_masked.csv",header = TRUE)
  #Selecting type = 'elect' and 'Dist_Heating'
  target = c("elect", "Dist_Heating")
  rawData1 = filter(rawData1,type %in% target)
  rawData1 = rawData1 %>% mutate(vac = ifelse(BuildingID == 81909,"Building 27",
                                              ifelse(BuildingID == 82254 | 
                                                       BuildingID == 83427 | 
                                                       BuildingID == 84681,
                                                     "Building 9",as.character(vac))))
  #Converting date to Date Format
  rawData1$date = as.Date(as.character(rawData1$date), format='%Y%m%d')
  #week of day
  rawData1$day <- weekdays(as.Date(rawData1$date))
  #Month of year
  rawData1$month <- months(as.Date(rawData1$date))
  #weekdays_weekend
  rawData1=rawData1 %>% mutate(Weekday = ifelse(day == 'Saturday'| day == 'Sunday',0,1))
  rawData1=rawData1 %>%mutate(Base_Hour_Flag= ifelse(hour == '0'|hour == '1' |
                                                         hour == '2'|hour == '3' |
                                                         hour == '4'|hour == '22'|
                                                         hour == '23',1,0))
  #holidayfinalscrape
  url<- 'http://www.timeanddate.com/holidays/finland/2013'
  webpage = read_html(url) %>%
    html_nodes(xpath='/html/body/div[1]/div[7]/article/section[1]/div[5]/table') %>%
    html_table()
  dataframe<-as.data.frame(webpage)
  col<- dataframe[-1,]
  date<-col$Date
  fullDate = paste("2013",date,sep=" ")
  col$Date = as.Date(as.character(fullDate), format='%Y %b %d')
  rawData1 = rawData1 %>% mutate(Holiday = ifelse(date %in% col$Date,1,0))
  
  return(rawData1)
}
#Function for creating seperate 78 or any number of files as per the Raw Data
createSeparateData = function(que,finData){
  dir.create("Buildings Data")
  setwd("Buildings Data")
  lengQuery = length(que$BuildingID)
  for (varb in 1:lengQuery){
    name = paste(que$BuildingName[varb],que$BuildingID[varb],que$MeterID[varb],que$type[varb],sep = "_")
    bdng = paste(name,".csv",sep="")
    sepData = filter(finData,BuildingName %in% que$BuildingName[varb],
                     BuildingID %in% que$BuildingID[varb],
                     MeterID  %in% que$MeterID[varb],
                     type %in% que$type[varb])
    write.csv(sepData,bdng,row.names = FALSE)
  }
  setwd("../")
}
#Function for base hour calculations:
baseHourCalculation = function(finRawData){
  finRawData = finalMergeData
  df2 = aggregate(Consumption~vac+type+Weekday+month+Holiday+Date,
                  mean,
                  data=subset(finRawData,Hours<3 | Hours>22 ))
  names(df2)[7]="base_hr_usage"
  p1 = inner_join(finRawData,df2,by = c("vac", "type", "Weekday","Date","month", "Holiday"))
  View(p1)
  p1=p1 %>% mutate(Base_Hour_Class= ifelse(Consumption> base_hr_usage,"High","Low"))
  pF = subset(p1, select = -c(lat,lon,area_floor._m.sqr))
  names(p1)[2]="BuildingName"
  names(p1)[3]="MeterID"
}