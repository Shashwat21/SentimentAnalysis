library(sqldf)
library(dplyr)
library(tidyr)
library(ggmap)
library(lubridate)
library(zoo)
#uniqCodes = unique(addData$nearestAiport)
createWeatherData = function(uniqCodes){
  dir.create("Weather Data")
  setwd("Weather Data")
  for (i in uniqCodes) {
    dfw_wx = getWeatherForDate(i, start_date="2013/01/01", end_date="2013/12/08",opt_detailed=TRUE,
                               opt_custom_columns=TRUE, custom_columns=c(2:13))
    #write.csv(dfw_wx,"Weather Data.csv",row.names = FALSE)
    #New variables added = 	Gust_SpeedMPH PrecipitationIn Events
    
    #---------------Setting the Wind_Speed = 0 for "Calm"           ---------------
    dfw_wx$Wind_SpeedMPH=ifelse(dfw_wx$Wind_SpeedMPH=='Calm',0,dfw_wx$Wind_SpeedMPH)
    
    #---------------Converting Wind_Speed and Humidity to numeric   ---------------
    dfw_wx$Wind_SpeedMPH=as.numeric(dfw_wx$Wind_SpeedMPH)
    dfw_wx$Humidity=as.numeric(dfw_wx$Humidity)
    
    #---------------Handling Outliers Values                        ---------------
    dfw_wx = dfw_wx %>% mutate(TemperatureF = ifelse(TemperatureF < -126 | TemperatureF > 136,NA,TemperatureF),
                               Dew_PointF = ifelse(Dew_PointF < -60 | Dew_PointF > 95,NA,Dew_PointF),
                               Humidity = ifelse(Humidity<0,NA,Humidity),
                               Sea_Level_PressureIn = ifelse(Sea_Level_PressureIn > 35 | Sea_Level_PressureIn <10,NA,Sea_Level_PressureIn),
                               VisibilityMPH = ifelse(VisibilityMPH > 10 | VisibilityMPH < -10,NA,VisibilityMPH),
                               Wind_SpeedMPH = ifelse(Wind_SpeedMPH > 1000 | Wind_SpeedMPH < 0,NA,Wind_SpeedMPH),
                               PrecipitationIn = ifelse(PrecipitationIn == 'NA',0,PrecipitationIn),
                               Gust_SpeedMPH = ifelse(Gust_SpeedMPH > 253 | Gust_SpeedMPH < 0,NA,Gust_SpeedMPH))
    gust = dfw_wx$Gust_SpeedMPH
    dfw_wx = dfw_wx[,-9]
    dfw_wx = dfw_wx %>% do(na.locf(.))
    dfw_wx$Gust_SpeedMPH = gust
    dfw_wx = dfw_wx %>% separate(Time,c("Date","Time_Stamp"),sep=" ")
    dfw_wx= dfw_wx %>% separate(Time_Stamp,c("Hours"),sep=":")
    
    #---------------Converting chr to numeric   ---------------
    dfw_wx$Wind_SpeedMPH=as.numeric(dfw_wx$Wind_SpeedMPH)
    dfw_wx$Humidity=as.numeric(dfw_wx$Humidity)
    dfw_wx$TemperatureF=as.numeric(dfw_wx$TemperatureF)
    dfw_wx$Dew_PointF=as.numeric(dfw_wx$Dew_PointF)
    dfw_wx$Sea_Level_PressureIn=as.numeric(dfw_wx$Sea_Level_PressureIn)
    dfw_wx$VisibilityMPH=as.numeric(dfw_wx$VisibilityMPH)
    dfw_wx$Hours=as.numeric(dfw_wx$Hours)
    dfw_wx$WindDirDegrees = as.numeric(dfw_wx$WindDirDegrees)
    dfw_wx$Gust_SpeedMPH = as.numeric(dfw_wx$Gust_SpeedMPH)
    
    dfw_wx1 = summarise(group_by(dfw_wx,Date,Hours),TemperatureF=mean(TemperatureF),Dew_PointF=mean(Dew_PointF),
                        Humidity=mean(Humidity),Sea_Level_PressureIn=mean(Sea_Level_PressureIn),
                        VisibilityMPH=mean(VisibilityMPH),Wind_Direction=max(Wind_Direction),
                        Wind_SpeedMPH=mean(Wind_SpeedMPH),Conditions=max(Conditions),
                        WindDirDegrees=mean(WindDirDegrees),Gust_SpeedMPH = mean(Gust_SpeedMPH),
                        PrecipitationIn = max(PrecipitationIn),Events = max(Events))
    dfw_wx1$Date = as.Date(dfw_wx1$Date)
    dfw_wx1$nearestAirport = i
    wName = paste("Weather Data-",i,".csv",sep="")
    write.csv(dfw_wx1,wName,row.names = FALSE)
  }
  
  #Creating a time sequence for missing hour calculations
  timeData = data.frame(seq(as.POSIXct("2013-01-01 00:00:00"), as.POSIXct("2013-12-08 23:59:59"), by="hour"))
  names(timeData)[1] = "DateTime"
  timeData = timeData %>% separate(DateTime,c("Date","Time"),11)
  timeData = timeData %>% separate(Time,"Hours",2)
  timeData = timeData[-3]
  timeData$Hours = as.numeric(timeData$Hours)
  timeData$Date = as.Date(as.character(timeData$Date),format = "%Y-%m-%d")
  
  for(i in uniqCodes){
    lnk = paste("Weather Data-",i,".csv",sep = "")
    flkn = paste("Final Weather Data-",i,".csv",sep="")
    newData = read.csv(lnk,header = TRUE)
    newData$Date = as.Date(as.character(newData$Date),format = "%Y-%m-%d")
    finalData = full_join(timeData,newData,by=c("Date","Hours"))
    finalData = finalData %>% do(na.locf(.))
    finalData$nearestAirport = i
    write.csv(finalData,flkn,row.names = FALSE)
  }
  
  #Create one final weather Data for all airports
  countVar = 0
  for(i in uniqCodes){
    finalLink = paste("Final Weather Data-",i,".csv",sep="")
    openFinal = read.csv(finalLink, header = TRUE)
    if (countVar == 0) {
      finalWeatherDF = openFinal
      countVar = countVar + 1
    }
    else{
      finalWeatherDF = rbind(finalWeatherDF,openFinal)
      countVar = countVar + 1
    }
  }
  return(finalWeatherDF)
  write.csv(finalWeatherDF,"Final-Weather.csv",row.names = FALSE)
  setwd("../")
}
