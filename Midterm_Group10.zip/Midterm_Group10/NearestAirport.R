library(dplyr)
library(tidyr)
library(ggmap)
library(RCurl)
library(XML)
library(rvest)
library(Imap)
library(zoo)

#Function for getting the nearest airport:
getDistance = function(bLat,bLon,stCodes,recLat,recLon){
  ctr = 1
  distance = ""
  rad <- pi/180
  R <- 6378.145
  for(i in stCodes){
    a1 <- recLat[ctr] * rad
    a2 <- recLon[ctr] * rad
    b1 <- bLat * rad
    b2 <- bLon * rad
    dlon <- b2 - a2
    dlat <- b1 - a1
    a <- (sin(dlat/2))^2 + cos(a1) * cos(b1) * (sin(dlon/2))^2
    c <- 2 * atan2(sqrt(a), sqrt(1 - a))
    
    distance[ctr] = R * c
    #print(distance[ctr])
    ctr = ctr + 1
  }
  
  return(stCodes[which.min(distance)])
}
nearestAirportCal = function(url,baseLat,baseLon){
  nearestAirport=""
  for(i in 1:length(url)){
    #Step1: Select airport under <airport> tags and getting the cities and station codes 
    cities = url[i] %>% 
      read_html() %>% 
      html_nodes("airport") %>% 
      html_nodes("station") %>% 
      html_nodes("city") %>% 
      html_text()
    stationCodes = url[i] %>% 
      read_html() %>% 
      html_nodes("airport") %>% 
      html_nodes("station") %>% 
      html_nodes("icao") %>% 
      html_text()
    lat = url[i] %>% 
      read_html() %>% 
      html_nodes("airport") %>% 
      html_nodes("station") %>% 
      html_nodes("lat") %>% 
      html_text()
    lon = url[i] %>% 
      read_html() %>% 
      html_nodes("airport") %>% 
      html_nodes("station") %>% 
      html_nodes("lon") %>% 
      html_text()
    #Step2: Clean the cities
    toSend = ''
    toSendStCode = ''
    toSendLat = ''
    toSendLon = ''
    ctr = 1
    lp = 1
    for(x in cities){
      if(x != "" && stationCodes[lp]!=""){
        toSend[ctr] = gsub("[,]\\s*[-]","",x)
        toSendStCode[ctr] = stationCodes[lp]
        toSendLat[ctr] = lat[lp]
        toSendLon[ctr] = lon[lp]
        ctr = ctr+1
      }
      lp = lp+1
    }  
    #Step3: Compute the distance between the city and the airports collected 
    toSendLat = as.numeric(toSendLat)
    toSendLon = as.numeric(toSendLon)
    nearestAirport[i] = getDistance(baseLat,baseLon,toSendStCode,toSendLat,toSendLon)
  }
  return(nearestAirport)
}
#distance[ctr] = gdist(lon.1 = bLon, 
#                      lat.1 = bLat, 
#                      lon.2 = recLon[ctr], 
#                      lat.2 = recLat[ctr], 
#                      units="miles")
