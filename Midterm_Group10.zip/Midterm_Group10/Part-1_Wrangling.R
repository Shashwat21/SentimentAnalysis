library(sqldf)
library(dplyr)
library(tidyr)
library(ggmap)
library(RCurl)
library(XML)
library(rvest)
library(geosphere)
library(weatherData)
library(zoo)
library(Imap)

#Reading the CSV's
addData = read.csv(file="Finland_addresses_area.csv",header = TRUE)
finland_Data = read.csv(file="Finland_masked.csv",header = TRUE)
names(addData)[1] = "vac"
names(addData)[2] = "address"

#Getting the latitude and longitude of all the address's provided
vac = addData$vac
geocodes = geocode(as.character(addData$address))
addData = data.frame(addData[,2:3],geocodes)
addData = cbind(addData,vac)

#Getting the URL's in variable updUrl
x = 1
for (i in addData$vac) {
  url = "http://api.wunderground.com/auto/wui/geo/GeoLookupXML/index.xml?query="
  updUrl = paste(paste0(url,addData$lat),addData$lon,sep = ",")
}

#Getting the nearest Aiport Station Code
source("NearestAirport.R")
for(i in 1:length(unique(updUrl))){
  stdCode = nearestAirportCal(updUrl[i],addData$lat[i],addData$lon[i])
  addData$nearestAiport[i] =stdCode
}

write.csv(addData,"New_Address.csv",row.names = FALSE)
unique(stdCode)

#Create Weather Data
source("WeatherScript.R")
uniqAirport = unique(addData$nearestAiport)
weatherData = createWeatherData(uniqAirport)


addrsData = read.csv(file = "New_Address.csv",header = TRUE)
  #setwd("Weather Data")
  #weatherData = read.csv(file = "Final-Weather.csv",header = TRUE)

#First Merge = Weather Data + New Address Data on (nearestAirport)
inn = inner_join(addrsData,weatherData,by = "nearestAirport")
inn$Date = as.Date(as.character(inn$Date),format = "%Y-%m-%d")
setwd("../")

#Second Merge = First Merge + Weather Data
source("BuildingSeperation.R")
filterData = getFilteredRaw(finland_Data)
names(filterData)[5] = "Date"
names(filterData)[6] = "Hours"
#2nd Merge
finalMergeData = inner_join(filterData,inn,by = c('vac',"Date","Hours"))
finalMergeData = finalMergeData %>% mutate(Consumption = Consumption/area_floor._m.sqr)
#Calculate Base_Hour_Class
finMer = baseHourCalculation(finalMergeData)
query = sqldf("Select DISTINCT BuildingID,BuildingName,MeterID,type from pF")
#Seperating Buidlgin Data
createSeparateData(query,pF)
write.csv(pF,"Final_Finland_Data.csv",row.names = FALSE)
queryTest = sqldf("Select DISTINCT Conditions from pF")
#################### Prediction #######################
#78 Buidlings Model
source("Loop_Prediction.R")
createRegression78(query)
createRandomForest78(query)
createNeuralNetwork78(query)
createKNN78(query)
#One Dataset
source("Prediction_OneDataset.R")
createKNNOne(finMer)
createRandomForestOne(finMer)
createNeuralNetworkOne(finMer)
createRegressionOne(finMer)

#################### Classification #######################