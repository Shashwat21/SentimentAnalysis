library(dplyr)
library(forecast)
library(leaps)
library(caret)
library(glmnet)
library(DAAG)
library(sqldf)
library(class)
library(FNN)
library(MASS)
library(grid)
library(neuralnet)
library(randomForest)
library(e1071)
library(caret)

createKNN78 = function(que){

  lengQuery = length(que$BuildingID)
  setwd("Buildings Data")
  
  for (varb in 1:lengQuery){
    name = paste(que$BuildingName[varb],que$BuildingID[varb],que$MeterID[varb],
                 que$type[varb],sep = "_")
    bdng = paste(name,".csv",sep="")
    knnModelData = read.csv(bdng,header = TRUE)
    if(sum(knnModelData$Consumption != 0)){
      knnModelData = knnModelData %>% select(-c(BuildingID,BuildingName,MeterID,
                                                type,Date,nearestAirport,Wind_Direction,
                                                Conditions,Gust_SpeedMPH,PrecipitationIn,
                                                Events,VisibilityMPH,address,Base_Hour_Class,
                                                day,month))
      
      knnModelData$TemperatureF = scale(as.numeric(knnModelData$TemperatureF),
                                        center = TRUE,scale = TRUE)
      knnModelData$Dew_PointF = scale(as.numeric(knnModelData$Dew_PointF),
                                      center = TRUE,scale = TRUE)
      knnModelData$Humidity = scale(as.numeric(knnModelData$Humidity),
                                    center = TRUE,scale = TRUE)
      knnModelData$Sea_Level_PressureIn = scale(as.numeric(knnModelData$Sea_Level_PressureIn),
                                                center = TRUE,scale = TRUE)
      knnModelData$Wind_SpeedMPH = scale(as.numeric(knnModelData$Wind_SpeedMPH),
                                         center = TRUE,scale = TRUE)
      knnModelData$WindDirDegrees = scale(as.numeric(knnModelData$WindDirDegrees),
                                          center = TRUE,scale = TRUE)
      knnModelData$base_hr_usage = scale(as.numeric(knnModelData$base_hr_usage),
                                         center = TRUE,scale = TRUE)
      knnModelData$WeekDay = scale(as.numeric(knnModelData$Weekday),
                                   center = TRUE,scale = TRUE)
      knnModelData$Base_Hour_Flag = scale(as.numeric(knnModelData$Base_Hour_Flag),
                                          center = TRUE,scale = TRUE)
      
      #70% of the sample size
      smp_size <- floor(0.70 * nrow(knnModelData))
      
      #Set the seed to make your partition reproducible.
      set.seed(123)
      train_ind <- sample(seq_len(nrow(knnModelData)), size = smp_size)
      
      #Splitting the data into training and testing
      train_data <- knnModelData[train_ind, ]
      test_data <- knnModelData[-train_ind, ]
      
      knn.model <- knn.reg(train_data[,-2], test_data[,-2], y = train_data$Consumption,
                           k = 5, algorithm= "kd_tree")
      knnDataFrame = data.frame(actual= test_data$Consumption, predicted = knn.model$pred)
      reg_acc<-accuracy(knnDataFrame$predicted, knnDataFrame$actual)
      
      if(varb == 1){
        rmseAppKNN =  reg_acc
        bnnd = bdng
      }
      else{
        rmseAppKNN = rbind(rmseAppKNN,reg_acc)    
        bnnd = rbind(bnnd,bdng)
      }
    }
  }
  rmseAppKNN = cbind(bnnd,rmseAppKNN)
  write.csv(rmseAppKNN, "RMSE_ALLBUILDINGS_KNN.csv", row.names=FALSE)
  setwd("../")
}

createNeuralNetwork78 = function(que){
  #Neural Network Modelling
  
  getwd()
  for (varb in 1:lengQuery){
    name = paste(que$BuildingName[varb],que$BuildingID[varb],que$MeterID[varb],
                 que$type[varb],sep = "_")
    bdng = paste(name,".csv",sep="")
    neuroModelData = read.csv(bdng,header = TRUE)
    if(sum(neuroModelData$Consumption != 0)){
      neuroModelData = neuroModelData %>% select(-c(BuildingID,BuildingName,MeterID,
                                                    type,Date,nearestAirport,Wind_Direction,
                                                    Conditions,Gust_SpeedMPH,PrecipitationIn,
                                                    Events,VisibilityMPH,address,Base_Hour_Class,
                                                    day,month))
      
      neuroModelData$TemperatureF = scale(as.numeric(neuroModelData$TemperatureF),
                                          center = TRUE,scale = TRUE)
      neuroModelData$Dew_PointF = scale(as.numeric(neuroModelData$Dew_PointF),
                                        center = TRUE,scale = TRUE)
      neuroModelData$Humidity = scale(as.numeric(neuroModelData$Humidity),
                                      center = TRUE,scale = TRUE)
      neuroModelData$Sea_Level_PressureIn = scale(as.numeric(neuroModelData$Sea_Level_PressureIn),
                                                  center = TRUE,scale = TRUE)
      neuroModelData$Wind_SpeedMPH = scale(as.numeric(neuroModelData$Wind_SpeedMPH),
                                           center = TRUE,scale = TRUE)
      neuroModelData$WindDirDegrees = scale(as.numeric(neuroModelData$WindDirDegrees),
                                            center = TRUE,scale = TRUE)
      neuroModelData$base_hr_usage = scale(as.numeric(neuroModelData$base_hr_usage),
                                           center = TRUE,scale = TRUE)
      neuroModelData$WeekDay = scale(as.numeric(neuroModelData$Weekday),
                                     center = TRUE,scale = TRUE)
      neuroModelData$Base_Hour_Flag = scale(as.numeric(neuroModelData$Base_Hour_Flag),
                                            center = TRUE,scale = TRUE)
      
      
      #70% of the sample size
      smp_size <- floor(0.70 * nrow(neuroModelData))
      
      #Set the seed to make your partition reproducible.
      set.seed(123)
      train_ind <- sample(seq_len(nrow(neuroModelData)), size = smp_size)
      
      #Splitting the data into training and testing
      train_data <- neuroModelData[train_ind, ]
      test_data <- neuroModelData[-train_ind, ]
      
      #Build the neural network (NN)
      creditnet <- neuralnet(Consumption ~ Weekday+Base_Hour_Flag+Holiday+TemperatureF+	
                               Humidity+Sea_Level_PressureIn+Wind_SpeedMPH+
                               WindDirDegrees+base_hr_usage, train_data, 
                             hidden =5, lifesign = "minimal", 
                             linear.output = TRUE, threshold = 0.1)
      ## test the resulting output
      temp_test <- subset(test_data, select = c("Weekday","Base_Hour_Flag","Holiday",
                                                "TemperatureF","Humidity",
                                                "Sea_Level_PressureIn","Wind_SpeedMPH",
                                                "WindDirDegrees","base_hr_usage"))
      
      creditnet.results <- compute(creditnet, temp_test)
      results <- data.frame(actual = test_data$Consumption, 
                            prediction = creditnet.results$net.result)
      #Checking the accuracy of the model
      reg_acc <- accuracy(results[,1],results[,2])
      if(varb == 1){
        rmseAppNeural =  reg_acc
        budnn = bdng
      }
      else{
        rmseAppNeural = rbind(rmseAppNeural,reg_acc)
        budnn = rbind(budnn,bdng)
      }
    }
  }
  rmseAppNeural = cbind(budnn,rmseAppNeural)
  write.csv(rmseAppNeural, "RMSE_ALLBUILDINGS_NEURALNETWORK.csv", row.names=FALSE)
  setwd("../")
}

createRandomForest78 = function(que){
  getwd()
  setwd("Buildings Data")
  for (varb in 1:lengQuery){
    name = paste(que$BuildingName[varb],que$BuildingID[varb],que$MeterID[varb],que$type[varb],sep = "_")
    bdng = paste(name,".csv",sep="")
    randoModelData = read.csv(bdng,header = TRUE)
    if(sum(randoModelData$Consumption != 0)){
      randoModelData = randoModelData %>% select(-c(BuildingID,BuildingName,MeterID,
                                                    type,Date,nearestAirport,Wind_Direction,
                                                    Conditions,Gust_SpeedMPH,PrecipitationIn,
                                                    Events,VisibilityMPH,address,Base_Hour_Class,
                                                    day,month))
      modelData$TemperatureF = scale(as.numeric(modelData$TemperatureF),
                                     center = TRUE,scale = TRUE)
      modelData$Dew_PointF = scale(as.numeric(modelData$Dew_PointF),
                                   center = TRUE,scale = TRUE)
      modelData$Humidity = scale(as.numeric(modelData$Humidity),
                                 center = TRUE,scale = TRUE)
      modelData$Sea_Level_PressureIn = scale(as.numeric(modelData$Sea_Level_PressureIn),
                                             center = TRUE,scale = TRUE)
      modelData$Wind_SpeedMPH = scale(as.numeric(modelData$Wind_SpeedMPH),
                                      center = TRUE,scale = TRUE)
      modelData$WindDirDegrees = scale(as.numeric(modelData$WindDirDegrees),
                                       center = TRUE,scale = TRUE)
      modelData$base_hr_usage = scale(as.numeric(modelData$base_hr_usage),
                                      center = TRUE,scale = TRUE)
      modelData$WeekDay = scale(as.numeric(modelData$Weekday),
                                center = TRUE,scale = TRUE)
      modelData$Base_Hour_Flag = scale(as.numeric(modelData$Base_Hour_Flag),
                                       center = TRUE,scale = TRUE)
      #70% of the sample size
      smp_size <- floor(0.70 * nrow(randoModelData))
      
      #Set the seed to make your partition reproducible.
      set.seed(123)
      train_ind <- sample(seq_len(nrow(randoModelData)), size = smp_size)
      
      #Splitting the data into training and testing
      train_data <- randoModelData[train_ind, ]
      test_data <- randoModelData[-train_ind, ]
      
      
      #building Randomforest
      rf.form<-Consumption ~ Weekday+Base_Hour_Flag+Holiday+TemperatureF+	
        Humidity+Sea_Level_PressureIn+Wind_SpeedMPH+
        WindDirDegrees+base_hr_usage
      
      cross.sell.rf <- randomForest(rf.form,
                                    train_data,
                                    ntree=200,
                                    importance=T)
      
      # Predicting response variable
      test_data$predicted.response <- predict(cross.sell.rf ,test_data)
      reg_acc<-accuracy(test_data$predicted.response, test_data$Consumption)
      rmse = sqrt(mean(mean(test_data$Consumption)-reg_acc)^2)
      if(varb == 1){
        rmseAppRandom1 =  reg_acc
        modelName1 = bdng
      }
      else{
        rmseAppRandom1 = rbind(rmseAppRandom1,reg_acc)
        modelName1 = rbind(modelName1,bdng)
      }
    }
  }
  rmseAppRandom1 = cbind(modelName1,rmseAppRandom1)
  write.csv(rmseAppRandom1, "RMSE_ALLBUILDINGS_RANDOMFOREST.csv", row.names=FALSE)
  setwd("../")
}

createRegression78 = function(que){
  
  setwd("Buildings Data")
  for (varb in 1:lengQuery){
    
    name = paste(que$BuildingName[varb],que$BuildingID[varb],que$MeterID[varb],que$type[varb],
                 sep = "_")
    bdng = paste(name,".csv",sep="")
    modelData = read.csv(bdng,header = TRUE)
    dimen = dim(modelData)
    if(sum(modelData$Consumption != 0)){
      modelData = modelData %>% select(-c(BuildingID,BuildingName,MeterID,
                                          type,Date,nearestAirport,Wind_Direction,
                                          Conditions,Gust_SpeedMPH,PrecipitationIn,
                                          Events,VisibilityMPH,address,Base_Hour_Class,
                                          day,month))
      modelData$TemperatureF = scale(as.numeric(modelData$TemperatureF),
                                     center = TRUE,scale = TRUE)
      modelData$Dew_PointF = scale(as.numeric(modelData$Dew_PointF),
                                   center = TRUE,scale = TRUE)
      modelData$Humidity = scale(as.numeric(modelData$Humidity),
                                 center = TRUE,scale = TRUE)
      modelData$Sea_Level_PressureIn = scale(as.numeric(modelData$Sea_Level_PressureIn),
                                             center = TRUE,scale = TRUE)
      modelData$Wind_SpeedMPH = scale(as.numeric(modelData$Wind_SpeedMPH),
                                      center = TRUE,scale = TRUE)
      modelData$WindDirDegrees = scale(as.numeric(modelData$WindDirDegrees),
                                       center = TRUE,scale = TRUE)
      modelData$base_hr_usage = scale(as.numeric(modelData$base_hr_usage),
                                      center = TRUE,scale = TRUE)
      modelData$WeekDay = scale(as.numeric(modelData$Weekday),
                                center = TRUE,scale = TRUE)
      modelData$Base_Hour_Flag = scale(as.numeric(modelData$Base_Hour_Flag),
                                       center = TRUE,scale = TRUE)
      
      #70% of the sample size
      smp_size <- floor(0.70 * nrow(modelData))
      
      #Set the seed to make your partition reproducible.
      set.seed(123)
      train_ind <- sample(seq_len(nrow(modelData)), size = smp_size)
      
      #Splitting the data into training and testing
      train_data <- modelData[train_ind, ]
      test_data <- modelData[-train_ind, ]
      
      #Fit a linear regression model
      lm.fit=lm(Consumption ~ Weekday+Base_Hour_Flag+Holiday+TemperatureF+	
                  Humidity+Sea_Level_PressureIn+Wind_SpeedMPH+
                  WindDirDegrees+base_hr_usage,
                data=train_data)
      #Cross validate 3 fold 
      #CVlm(ModellingData, lm.fit, m=3)
      
      reg_pred = predict(lm.fit, test_data)
      reg_acc<-accuracy(reg_pred, test_data$Consumption)
      #rmse = sqrt(mean(mean(test_data$Consumption)-reg_acc)^2)
      
      if(varb == 1){
        rmseApp2 = reg_acc
        modelName = bdng
      }
      else{
        rmseApp2 = rbind(rmseApp2,reg_acc)
        modelName = rbind(modelName,bdng)
      }
    }
  }
  rmseApp2 = cbind(modelName,rmseApp2)
  names(rmseApp2)[1] = "Model"
  View(rmseApp2)
  write.csv(rmseApp2, "RMSE_ALLBUILDINGS_REGRESSION.csv", row.names=FALSE)
  setwd("../")
}